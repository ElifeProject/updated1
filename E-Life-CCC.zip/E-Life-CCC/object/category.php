<?php
class Category{
	private $conn;
	private $table_name = "catalogue";
	public $Catagory_id;
	public $Catagory_title;
	public function __construct($db){
		$this->conn=$db;

	}
	 function read(){
		$query = "SELECT Catagory_id, Catagory_title FROM " .$this->table_name . " ORDER BY Catagory_id";
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		return $stmt;


	}
	function readName(){
		$query =  "SELECT Catagory_title FROM " .$this->table_name . " WHERE Catagory_id=? limit 0,1";

		$stmt=$this->conn->prepare($query);
		$stmt->bindParam(1, $this->Catagory_id);
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$this->Catagory_title = $row['Catagory_title'];
	}
}
?>